﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$.Forms
{
    public partial class GridForm : Form
    {
        MainForm _myParent = null;
        int whichReport = 0;

        public GridForm(MainForm myParent, int display)
        {
            _myParent = myParent;
            whichReport = display;

            InitializeComponent();

            switch (display)
            {
                case 0:
                    this.Text = "Inspections Per Year";
                    displayInspectionsPerYear();
                    break;
                case 1:
                    this.Text = "Restaurants Per Year";
                    displayRestaurantsPerYear();
                    break;
            }
        }

        private void displayInspectionsPerYear()
        {
            DataGridView_GF_All.Columns.Add("colYear", "Year");
            DataGridView_GF_All.Columns.Add("colInspect", "Inspections");

            List<int> yearSort = new List<int>(_myParent.inspectionsPerYear.Keys);
            yearSort.Sort();

            for (int yearLoop = 0; yearLoop < yearSort.Count; yearLoop++)
            {
                int yearNum = yearSort.ElementAt(yearLoop);
                int inspectCount = _myParent.inspectionsPerYear[yearNum];

                DataGridView_GF_All.Rows.Add(yearNum, inspectCount);
            }
        }

        private void displayRestaurantsPerYear()
        {
            DataGridView_GF_All.Columns.Add("colYear", "Year");
            DataGridView_GF_All.Columns.Add("colInspect", "Restaurants");

            List<int> yearSort = new List<int>(_myParent.restaurantsPerYear.Keys);
            yearSort.Sort();

            for (int yearLoop = 0; yearLoop < yearSort.Count; yearLoop++)
            {
                int yearNum = yearSort.ElementAt(yearLoop);
                int inspectCount = _myParent.restaurantsPerYear[yearNum].Count;

                DataGridView_GF_All.Rows.Add(yearNum, inspectCount);
            }
        }

        private void Button_GR_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button_GF_CopyToCliipboard_Click(object sender, EventArgs e)
        {

            String clipboardText = "";
            if (whichReport == 0)
            {
                clipboardText = "\"Inspections Per Year\"\n";
                clipboardText += "\"Year\",\"Inspections\"\n";

                List<int> yearSort = new List<int>(_myParent.inspectionsPerYear.Keys);
                yearSort.Sort();

                for (int yearLoop = 0; yearLoop < yearSort.Count; yearLoop++)
                {
                    int yearNum = yearSort.ElementAt(yearLoop);
                    int inspectCount = _myParent.inspectionsPerYear[yearNum];

                    clipboardText += yearNum.ToString() + "," + inspectCount.ToString() + "\n";
                }

            }
            else if (whichReport == 1)
            {
                clipboardText = "\"Restaurants Per Year\"\n";
                clipboardText += "\"Year\",\"Restaurants\"\n";

                List<int> yearSort = new List<int>(_myParent.restaurantsPerYear.Keys);
                yearSort.Sort();

                for (int yearLoop = 0; yearLoop < yearSort.Count; yearLoop++)
                {
                    int yearNum = yearSort.ElementAt(yearLoop);
                    int inspectCount = _myParent.restaurantsPerYear[yearNum].Count;

                    clipboardText += yearNum.ToString() + "," + inspectCount.ToString() + "\n";
                }
            }




            Clipboard.SetText(clipboardText);
        }
    }
}
