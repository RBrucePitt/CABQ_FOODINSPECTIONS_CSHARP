﻿namespace $safeprojectname$.Forms
{
    partial class GridForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DataGridView_GF_All = new System.Windows.Forms.DataGridView();
            this.Button_GF_CopyToCliipboard = new System.Windows.Forms.Button();
            this.Button_GR_Close = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_GF_All)).BeginInit();
            this.SuspendLayout();
            // 
            // DataGridView_GF_All
            // 
            this.DataGridView_GF_All.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView_GF_All.Location = new System.Drawing.Point(2, 42);
            this.DataGridView_GF_All.Name = "DataGridView_GF_All";
            this.DataGridView_GF_All.Size = new System.Drawing.Size(252, 498);
            this.DataGridView_GF_All.TabIndex = 0;
            // 
            // Button_GF_CopyToCliipboard
            // 
            this.Button_GF_CopyToCliipboard.Location = new System.Drawing.Point(12, 12);
            this.Button_GF_CopyToCliipboard.Name = "Button_GF_CopyToCliipboard";
            this.Button_GF_CopyToCliipboard.Size = new System.Drawing.Size(128, 23);
            this.Button_GF_CopyToCliipboard.TabIndex = 2;
            this.Button_GF_CopyToCliipboard.Text = "Copy to Clipboard";
            this.Button_GF_CopyToCliipboard.UseVisualStyleBackColor = true;
            this.Button_GF_CopyToCliipboard.Click += new System.EventHandler(this.Button_GF_CopyToCliipboard_Click);
            // 
            // Button_GR_Close
            // 
            this.Button_GR_Close.Location = new System.Drawing.Point(174, 12);
            this.Button_GR_Close.Name = "Button_GR_Close";
            this.Button_GR_Close.Size = new System.Drawing.Size(75, 23);
            this.Button_GR_Close.TabIndex = 3;
            this.Button_GR_Close.Text = "Close";
            this.Button_GR_Close.UseVisualStyleBackColor = true;
            this.Button_GR_Close.Click += new System.EventHandler(this.Button_GR_Close_Click);
            // 
            // GridForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(261, 552);
            this.Controls.Add(this.Button_GR_Close);
            this.Controls.Add(this.Button_GF_CopyToCliipboard);
            this.Controls.Add(this.DataGridView_GF_All);
            this.Name = "GridForm";
            this.Text = "GridForm - Title";
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_GF_All)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView DataGridView_GF_All;
        private System.Windows.Forms.Button Button_GF_CopyToCliipboard;
        private System.Windows.Forms.Button Button_GR_Close;
    }
}