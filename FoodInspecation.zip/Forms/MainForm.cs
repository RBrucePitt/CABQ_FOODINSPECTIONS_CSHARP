﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Threading;

using $safeprojectname$.Forms;

namespace $safeprojectname$
{
    public partial class MainForm : Form
    {

        #region Globals

        String helpMsg = "This program will count record sets in either a CSV file or an XML file," +
                         "or a directory of CSV files, or a directory of XML files";

        String aboutMsg = "Count Records - Version 1.0.1\n\nAuthor: R. Bruce Pitt";

        Thread runThread = null;

        int singleCSVCount = 0;
        int csvFileCount = 0;
        int csvRecordCount = 0;

        UInt32 totalDataRead = 0;
        UInt32 totalDataLines = 0;
        Decimal averageRecordSize = 0.0M;

        DateTime startTime;
        DateTime endTime;

        List<String> xmlFilesFound = new List<String>();
        List<String> csvFilesFound = new List<String>();

        bool processingOn = false;
        List<String> rawHeader = null;
        Dictionary<String, int> headingInfo = new Dictionary<String, int>();    // Heading Text, Position
        Dictionary<int, String> headingPosInfo = new Dictionary<int, String>(); // Position, Heading Text

        // Post Data Processing - Food CSV Fields
        // "FACILITY_NAME\tFACILITY_KEY\tSITE_ADDRESS\tCITY\tSTATE\tZIP\tOWNER_KEY\tOWNER_NAME\tNATURE_OF_BUSINESS\tSTREET_NUMBER\tSTREET_NAME\tSTREET_TYPE\tPOST_DIRECTIONAL\tPHONE\tPROGRAM_CATEGORY\tPROGRAM_CATEGORY_DESCRIPTION\tINSPECTION_DATE\tINSPECTION_TYPE\tINSPECTION_DESC\tSERIAL_NUM\tACTION_CODE\tACTION_DESC\tRESULT_CODE\tRESULT_DESC\tVIOLATION_CODE\tVIOLATION_DESC\tINSPECTION_MEMO"
        //      0              1            2           3      4      5     6          7            8                   9           10                11          12            13          14              15                            16               17               18             19            20           21           22           23           24                25           26                                                       
        // "FACILITY_NAME\tFACILITY_KEY\tSITE_ADDRESS\tCITY\tSTATE\tZIP\tOWNER_KEY\tOWNER_NAME\tNATURE_OF_BUSINESS\tSTREET_NUMBER\tSTREET_NAME\tSTREET_TYPE\tPOST_DIRECTIONAL\tPHONE\tPROGRAM_CATEGORY\tPROGRAM_CATEGORY_DESCRIPTION\tINSPECTION_DATE\tINSPECTION_TYPE\tINSPECTION_DESC\tSERIAL_NUM\tACTION_CODE\tACTION_DESC\tRESULT_CODE\tRESULT_DESC\tVIOLATION_CODE\tVIOLATION_DESC\tINSPECTION_MEMO"

        int infoItems = 14;

        int facKeyItem = -1;
        int ownKeyItem = -1;
        int inspectKeyItem = -1;
        int inpectDateItem = -1;

        // Actual Processed Information
        public Dictionary<int, int> inspectionsPerYear = new Dictionary<int, int>();     // Year, Count
        public Dictionary<String, int> uniqueInspections = new Dictionary<string, int>();  // SEQ_NUM, Record Count
        public Dictionary<String, Dictionary<String, String>> restaurants = new Dictionary<String, Dictionary<String, String>>();  // Key, Info Fields
        public Dictionary<int, Dictionary<String, int>> restaurantsPerYear = new Dictionary<int, Dictionary<String, int>>();  // Year, FacKey, Count of Inspections this year
        public Dictionary<String, Dictionary<String, String>> owners = new Dictionary<String, Dictionary<String, String>>(); // OwnerKey, FacKey

        int ownsMoreThanOne = 0;

        #endregion // Globals

        public MainForm()
        {
            InitializeComponent();
        }

        #region ButtonFunctions

        private void Button_MF_Exit_Click(object sender, EventArgs e)
        {
            if (runThread != null)
            {
                runThread.Abort();
                Thread.Sleep(2);
            }
            this.Close();
        }

        private void Button_MF_IP_CSVSingle_Browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog_SelectFile = new OpenFileDialog();

            if (openFileDialog_SelectFile.ShowDialog() == DialogResult.OK)
            {
                TextBox_IP_MF_CSVSingle.Text = openFileDialog_SelectFile.FileName;
            }

            TextBox_IP_MF_CSVSingle.Refresh();
        }

        private void Button_MF_IP_CSVDir_Browse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog openDirDialog_SelectFile = new FolderBrowserDialog();

            if (openDirDialog_SelectFile.ShowDialog() == DialogResult.OK)
            {
                TextBox_MF_IP_InputCSV_Dir.Text = openDirDialog_SelectFile.SelectedPath;
            }

            this.Refresh();
        }

        private void Button_MF_IP_OutDir_Browse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog openDirDialog_SelectFile = new FolderBrowserDialog();

            if (openDirDialog_SelectFile.ShowDialog() == DialogResult.OK)
            {
                TextBox_MF_IP_OutputResultsDir.Text = openDirDialog_SelectFile.SelectedPath;
            }

            this.Refresh();
        }

        private void _MF_IP_CSVSingle_Clear_Click(object sender, EventArgs e)
        {
            TextBox_IP_MF_CSVSingle.Text = "";
            TextBox_IP_MF_CSVSingle.Refresh();
        }

        private void Button_MF_IP_CSVDir_Clear_Click(object sender, EventArgs e)
        {
            TextBox_MF_IP_InputCSV_Dir.Text = "";
            TextBox_MF_IP_InputCSV_Dir.Refresh();
        }

        private void Button_MF_IP_XMLDir_Clear_Click(object sender, EventArgs e)
        {
            TextBox_MF_IP_OutputResultsDir.Text = "";
            TextBox_MF_IP_OutputResultsDir.Refresh();
        }

        private void Button_MF_Help_Click(object sender, EventArgs e)
        {
            MessageBox.Show(helpMsg, "Help");
        }

        private void Button_MF_POST_PROCRESS_Click(object sender, EventArgs e)
        {
            if (runThread != null)
            {
                MessageBox.Show("Already Running", "Error");
                return;
            }

            processingOn = true;
            runThreadNow();

        }

        private void Button_MF_Run_Click(object sender, EventArgs e)
        {
            if (runThread != null)
            {
                MessageBox.Show("Already Running", "Error");
                return;
            }

            processingOn = false;
            runThreadNow();
         
        }

        private void Button_MF_Export_Click(object sender, EventArgs e)
        {
            // Figure out our path
            String dirPath = "";
            if (TextBox_MF_IP_OutputResultsDir.Text != "")
            {
                dirPath = TextBox_MF_IP_OutputResultsDir.Text;
            }
            else
            {
                dirPath = Directory.GetCurrentDirectory();
            }

            if (dirPath.ElementAt(dirPath.Length-1) != '\\')
            {
                dirPath = dirPath + "\\";
            }

            // Always add dateTime
            DateTime timeNow = DateTime.Now;
            String timeNowStg = timeNow.Year.ToString("D4") + "-" + timeNow.Month.ToString("D2") + "-" + timeNow.Day.ToString("D2");
            timeNowStg += "T" + timeNow.Hour.ToString("D2") + "-" + timeNow.Minute.ToString("D2") + "-" + timeNow.Second.ToString("D2");

            // Output to a bunch of files in CSV format
            StreamWriter outBigResults1 = new StreamWriter(dirPath + "_" + timeNowStg + "_OverAll.csv");

            int totalFiles = 0;
            if (TextBox_MF_IP_InputCSV_Dir.Text != "")
                totalFiles++;
            if (TextBox_MF_IP_InputCSV_Dir.Text != "")
                totalFiles += csvFileCount;
            outBigResults1.WriteLine("\"Total Files\", " + totalFiles.ToString());

            int totalRecords = 0;
            if (TextBox_MF_IP_InputCSV_Dir.Text != "")
                totalRecords += singleCSVCount;
            if (TextBox_MF_IP_InputCSV_Dir.Text != "")
                totalRecords += csvRecordCount;
            outBigResults1.WriteLine("\"Total Records\", " + totalRecords.ToString());

            outBigResults1.WriteLine("\"Total Bytes Read\", " + totalDataRead.ToString());
            outBigResults1.WriteLine("\"Total Data Lines Read\", " + totalDataLines.ToString());
            outBigResults1.WriteLine("\"averageRecordSize\", " + averageRecordSize.ToString());

            outBigResults1.WriteLine("\"Total Unique Inspections\", " + uniqueInspections.Count.ToString());
            outBigResults1.WriteLine("\"Restaurants Found\", " + restaurants.Count.ToString());
            outBigResults1.WriteLine("\"Owners Found\", " + owners.Count.ToString());
            outBigResults1.WriteLine("\"Own's Multiple (2+)\", " + ownsMoreThanOne.ToString());
            outBigResults1.Close();

            // Output to a bunch of files in CSV format
            StreamWriter outBigResults2 = new StreamWriter(dirPath + "_" + timeNowStg + "_InspectPerYear.csv");

            List<int> yearSort1 = new List<int>(inspectionsPerYear.Keys);
            yearSort1.Sort();
            outBigResults2.WriteLine("\"Year\", \"Inspections\"");
            for (int yearLoop = 0; yearLoop < yearSort1.Count; yearLoop++)
            {
                int yearNum = yearSort1.ElementAt(yearLoop);
                int inspectCount = inspectionsPerYear[yearNum];
                outBigResults2.WriteLine(yearNum.ToString("D4") + "," + inspectCount.ToString());
            }
            outBigResults2.Close();

            // Output to a bunch of files in CSV format
            StreamWriter outBigResults3 = new StreamWriter(dirPath + "_" + timeNowStg + "_RestaurantsPerYear.csv");

            List<int> yearSort2 = new List<int>(restaurantsPerYear.Keys);
            yearSort2.Sort();
            outBigResults3.WriteLine("\"Year\", \"Restaurant Count\"");
            for (int yearLoop = 0; yearLoop < yearSort2.Count; yearLoop++)
            {
                int yearNum = yearSort2.ElementAt(yearLoop);
                int restaurantCount = restaurantsPerYear[yearNum].Count;
                outBigResults3.WriteLine(yearNum.ToString("D4") + "," + restaurantCount.ToString());
            }
            outBigResults3.Close();


        }

        private void Button_MF_About_Click(object sender, EventArgs e)
        {
            MessageBox.Show(aboutMsg, "About");
        }

        private void Button_MF_PPR_InspPerYear_Click(object sender, EventArgs e)
        {
            GridForm gfForm = new GridForm(this, 0);
            gfForm.ShowDialog();
        }

        private void Button_MF_PPR_RestPerYear_Click(object sender, EventArgs e)
        {
            GridForm gfForm = new GridForm(this, 1);
            gfForm.ShowDialog();
        }

        #endregion // ButtonFunctions

        #region postFunctions

        private void PostSingleCSVCount(int count)
        {
            if (this.InvokeRequired)
            {
                // We're on a thread other than the GUI thread
                this.Invoke(new MethodInvoker(() => PostSingleCSVCount(count)));
                return;
            }

            TextBox_MF_RR_CSVSingle_Count.Text = count.ToString();
        }

        private void PostDirCSVFileCount(int count)
        {
            if (this.InvokeRequired)
            {
                // We're on a thread other than the GUI thread
                this.Invoke(new MethodInvoker(() => PostDirCSVFileCount(count)));
                return;
            }

            TextBox_MF_RR_CSVDir_FileCount.Text = count.ToString();
        }

        private void PostDirCSVRecordCount(int count)
        {
            if (this.InvokeRequired)
            {
                // We're on a thread other than the GUI thread
                this.Invoke(new MethodInvoker(() => PostDirCSVRecordCount(count)));
                return;
            }

            TextBox_MF_RR_CSVDir_RecordCount.Text = count.ToString();
        }

        private void PostStatus(String statusMsg)
        {
            if (this.InvokeRequired)
            {
                // We're on a thread other than the GUI thread
                this.Invoke(new MethodInvoker(() => PostStatus(statusMsg)));
                return;
            }

            ListBox_MF_Status.Items.Insert(0, statusMsg);
        }

        private void PostThreadDone()
        {
            if (this.InvokeRequired)
            {
                // We're on a thread other than the GUI thread
                this.Invoke(new MethodInvoker(() => PostThreadDone()));
                return;
            }

            endTime = DateTime.Now;
            TextBox_MF_PPR_EndTime.Text = endTime.ToShortTimeString();

            runThread = null;
        }

        private void PostUniqueInspections()
        {
            if (this.InvokeRequired)
            {
                // We're on a thread other than the GUI thread
                this.Invoke(new MethodInvoker(() => PostUniqueInspections()));
                return;
            }

            TextBox_MF_PPR_UniqueInspections.Text = uniqueInspections.Count().ToString();
        }

        private void PostRestaurantCount()
        {
            if (this.InvokeRequired)
            {
                // We're on a thread other than the GUI thread
                this.Invoke(new MethodInvoker(() => PostRestaurantCount()));
                return;
            }

            TextBox_MF_PPR_RestFound.Text = restaurants.Count().ToString();
        }

        private void PostOwnerCount()
        {
            if (this.InvokeRequired)
            {
                // We're on a thread other than the GUI thread
                this.Invoke(new MethodInvoker(() => PostOwnerCount()));
                return;
            }

            TextBox_MF_PPR_OwnersFound.Text = owners.Count().ToString();
        }

        private void PostOwnerMultiple()
        {
            if (this.InvokeRequired)
            {
                // We're on a thread other than the GUI thread
                this.Invoke(new MethodInvoker(() => PostOwnerMultiple()));
                return;
            }

            TextBox_MF_PPR_OwnersMuliple.Text = ownsMoreThanOne.ToString();
        }     


        #endregion // postFunctions

        #region RunThreadFunctions

        private void runThreadNow()
        {

            ListBox_MF_Status.Items.Clear();
            singleCSVCount = 0;
            csvFileCount = 0;
            csvRecordCount = 0;
            xmlFilesFound.Clear();
            csvFilesFound.Clear();

            facKeyItem = -1;
            ownKeyItem = -1;
            inspectKeyItem = -1;
            inpectDateItem = -1;

            startTime = DateTime.Now;
            TextBox_MF_PPR_StartTime.Text = startTime.ToShortTimeString();

            runThread = new Thread(runThreadMain);
            runThread.Start();
        }

        private void runThreadMain()
        {
            PostStatus("Starting run");

            if (TextBox_IP_MF_CSVSingle.Text != "")
            {
                PostStatus("Processing Single CSV");
                singleCSVCount = processCSVFile(TextBox_IP_MF_CSVSingle.Text, false, 0);
                PostSingleCSVCount(singleCSVCount);
                PostStatus("Avg Rcd Sz: " + averageRecordSize.ToString("F2"));
            }

            if (TextBox_MF_IP_InputCSV_Dir.Text != "")
            {
                PostStatus("Reading File List for CSV Directory");
                List<String> csvFileList = getDirFiles(TextBox_MF_IP_InputCSV_Dir.Text, ".csv");
                if (csvFileList.Count == 0)
                {
                    PostStatus("No CSV files found - skipping");
                }
                else
                {
                    for (int fLoop = 0; fLoop < csvFileList.Count; fLoop++)
                    {
                        csvFileCount = fLoop + 1;
                        PostDirCSVFileCount(fLoop + 1);
                        String fileName = Path.GetFileName(csvFileList.ElementAt(fLoop));
                        PostStatus("File: " + fileName);
                        csvRecordCount += processCSVFile(csvFileList.ElementAt(fLoop), true, csvRecordCount);
                        PostDirCSVRecordCount(csvRecordCount);
                    }
                    PostStatus("Avg Rcd Sz: " + averageRecordSize.ToString("F2"));
                }
            }


            PostStatus("Ending Run");

            PostThreadDone();
        }

        #endregion // RunThreadFunctions

        #region FileProcessingFunctions

        private int processCSVFile(String filePath, bool updatePostDirOrSingle, int baseCount)
        {
            int counter = 0;
            string line;

            // Read the file and display it line by line.
            if (!File.Exists(filePath))
                return (0);

            System.IO.StreamReader file = new System.IO.StreamReader(filePath);
            while ((line = file.ReadLine()) != null)
            {
                // Overall Stats
                totalDataRead += (UInt32) line.Length;
                totalDataLines++;
                averageRecordSize = Convert.ToDecimal(totalDataRead) / Convert.ToDecimal(totalDataLines);

                // Do we process?
                if (processingOn)
                {
                    if (counter == 0)
                    {
                        rawHeader = csvLineSplitFunction(line, '\t');
                        headingInfo.Clear();
                        headingPosInfo.Clear();
                        for (int hdrLoop = 0; hdrLoop < rawHeader.Count; hdrLoop++)
                        {
                            String thisHeaderText = rawHeader.ElementAt(hdrLoop);
                            headingInfo.Add(thisHeaderText, hdrLoop);
                            headingPosInfo.Add(hdrLoop, thisHeaderText);

                            // Determine which field is our main name ident
                            if (thisHeaderText == "FACILITY_KEY")
                                facKeyItem = hdrLoop;
                            // Determine which field is our owner ident
                            if (thisHeaderText == "OWNER_KEY")
                                ownKeyItem = hdrLoop;
                            // Determine which field is out inspector code
                            if (thisHeaderText == "SERIAL_NUM")
                                inspectKeyItem = hdrLoop;
                            // When did this happen
                            if (thisHeaderText == "INSPECTION_DATE")
                                inpectDateItem = hdrLoop;
                            
                        }
                    }
                    else
                    {
                        if ((facKeyItem == -1) || (ownKeyItem == -1) || (inspectKeyItem == -1) || (inpectDateItem == -1))
                        {
                            PostStatus("Can Not Process File");
                            PostStatus("Missing Fields");
                            file.Close();
                            return (0);
                        }

                        List<String> nextRecordEntry = csvLineSplitFunction(line, '\t');
                        processFoodRecord(ref nextRecordEntry);
                    }
                }

                counter++;
                if ((counter % 100) == 0)
                {
                    if (updatePostDirOrSingle)
                    {
                        PostDirCSVRecordCount(baseCount + counter);
                    }
                    else
                    {
                        PostSingleCSVCount(baseCount + counter);
                    }
                }
            }

            file.Close();

            return (counter);
        }

        private List<String> getDirFiles(String dirPath, String extension)
        {
            List<String> filesFound = new List<String>();

            try
            {
                foreach (string fName in Directory.GetFiles(dirPath))
                {
                    if (fName.IndexOf(extension) != -1)
                    {
                        filesFound.Add(fName);
                    }
                }

            }
            catch (System.Exception excpt)
            {
                PostStatus("Dir Scan Exception: " + excpt.Message);
            }

            return (filesFound);
        }

        private List<String> csvLineSplitFunction(String sourceLine, char separator)
        {
            List<String> retStrings = new List<String>();

            String currString = "";
            Boolean inQuotes = false;
            Int32 currStringCount = 0;

            // Look for a comma or tab unless we are in quotes, then we ignore commas or tab until new quote
            for (int stringLoop = 0; stringLoop < sourceLine.Length; stringLoop++)
            {
                char thisChar = sourceLine.ElementAt(stringLoop);
                if (inQuotes)
                {
                    if (thisChar == '\"')
                    {
                        inQuotes = false;   // Let next "," terminate
                    }
                    else
                    {
                        currString += thisChar;
                        currStringCount++;
                    }
                }
                else if (thisChar == separator)
                {
                    retStrings.Add(currString);
                    currStringCount = 0;
                    currString = "";
                }
                else if (thisChar == '\"')
                {
                    if (currStringCount == 0) // Should always be zero
                    {
                        inQuotes = true;
                    }
                }
                else
                {
                    currString += thisChar;
                    currStringCount++;
                }
            }

            // If we have any left in our buffer, then it is the last one before the \r\n
            if (currStringCount != 0)
                retStrings.Add(currString);

            return (retStrings);
        }

        private DateTime convertDateTime(String dateTimeStg)
        {
            // TBD Make Smarter or use DateTime converts

            // Assumes yyyy-mm-dd<SPACE>hh:mm:ss
            String [] dateTimeSplit1 = dateTimeStg.Split(' ');
            String [] dateParts = dateTimeSplit1[0].Split('-');
            String [] timeParts = dateTimeSplit1[1].Split(':');

            int year = Convert.ToInt32(dateParts[0]);
            int month = Convert.ToInt32(dateParts[1]);
            int day = Convert.ToInt32(dateParts[2]);

            int hour = Convert.ToInt32(timeParts[0]);
            int minute = Convert.ToInt32(timeParts[1]);
            int second = Convert.ToInt32(timeParts[2]);

            DateTime retVal = new DateTime(year, month, day, hour, minute, second);
            return (retVal);
        }

        #endregion // FileProcessingFunctions

        #region DataSpecificProcessing

        private void processFoodRecord(ref List<String>nextRecordEntry)
        {
            String facKey = nextRecordEntry[facKeyItem];
            String ownKey = nextRecordEntry[ownKeyItem];
            String inspectId = nextRecordEntry[inspectKeyItem];
            String inspectDate = nextRecordEntry[inpectDateItem];

            DateTime inspectDateTime = convertDateTime(inspectDate);

            // Unique Inspections
            bool dupInspect = false;
            if (uniqueInspections.ContainsKey(inspectId))
            {
                dupInspect = true;
                // was: uniqueInspections[inspectId]++;
            }
            else
            {
                uniqueInspections.Add(inspectId, 1);
                uniqueInspections[inspectId]++;
                PostUniqueInspections();
            }


            // Save Off Restaurant Info
            if (!restaurants.ContainsKey(facKey))   // The first N fields are Info
            {
                Dictionary<String, String> rInfo = new Dictionary<String, String>();
                for (int infoLoop = 0; infoLoop < infoItems; infoLoop++)
                {
                    rInfo.Add(headingPosInfo[infoLoop], nextRecordEntry[infoLoop]);
                }

                // One We Created to track total inpections
                restaurants.Add(facKey, rInfo);
                PostRestaurantCount();
            }

            // Track Inspections
            if (!dupInspect)
            {
                if (inspectionsPerYear.ContainsKey(inspectDateTime.Year))
                {
                    inspectionsPerYear[inspectDateTime.Year]++;
                }
                else
                {
                    inspectionsPerYear.Add(inspectDateTime.Year, 1);
                }
            }


            if (!restaurantsPerYear.ContainsKey(inspectDateTime.Year))
            {
                Dictionary<String, int> rYearly = new Dictionary<string, int>();
                rYearly.Add(facKey, 1);
                restaurantsPerYear.Add(inspectDateTime.Year, rYearly);
            }
            else
            {
                if (!restaurantsPerYear[inspectDateTime.Year].ContainsKey(facKey))
                {
                    restaurantsPerYear[inspectDateTime.Year].Add(facKey, 1);
                }
                else
                {
                    restaurantsPerYear[inspectDateTime.Year][facKey]++;
                }
            }

            // Now save off owners
            if (!owners.ContainsKey(ownKey))
            {
                Dictionary<String, String> facList = new Dictionary<String, String>();
                facList.Add(facKey, facKey);
                owners.Add(ownKey, facList);
                PostOwnerCount();
            }
            else
            {
                if (!owners[ownKey].ContainsKey(facKey))
                {
                    if (owners[ownKey].Count == 1)  // Second is only counted
                    {
                        ownsMoreThanOne++;
                        PostOwnerMultiple();
                    }
                    Dictionary<String, String> facList = new Dictionary<String, String>();
                    owners[ownKey].Add(facKey, facKey);
                }
            }

        }


        #endregion // DataSpecificProcessing


    }
}
