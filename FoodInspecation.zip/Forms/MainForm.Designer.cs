﻿namespace $safeprojectname$
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_MF_NMTC_Logo = new System.Windows.Forms.GroupBox();
            this.Label_MF_NMTC_Title2 = new System.Windows.Forms.Label();
            this.Label_MF_NMTC_Title1 = new System.Windows.Forms.Label();
            this.Label_MF_IP_InputCSV_File = new System.Windows.Forms.Label();
            this.GroupBox_MF_InputParameters = new System.Windows.Forms.GroupBox();
            this.Button_MF_IP_CSVDir_Clear = new System.Windows.Forms.Button();
            this._MF_IP_CSVSingle_Clear = new System.Windows.Forms.Button();
            this.Button_MF_IP_OutputResultsDir_Browse = new System.Windows.Forms.Button();
            this.TextBox_MF_IP_OutputResultsDir = new System.Windows.Forms.TextBox();
            this.Label_MF_IP_OutputResultsDir = new System.Windows.Forms.Label();
            this.Button_MF_IP_CSVDir_Browse = new System.Windows.Forms.Button();
            this.TextBox_MF_IP_InputCSV_Dir = new System.Windows.Forms.TextBox();
            this.Label_MF_IP_InputCSV_Dir = new System.Windows.Forms.Label();
            this.Button_MF_IP_CSVSingle_Browse = new System.Windows.Forms.Button();
            this.TextBox_IP_MF_CSVSingle = new System.Windows.Forms.TextBox();
            this.Button_MF_Exit = new System.Windows.Forms.Button();
            this.Button_MF_Help = new System.Windows.Forms.Button();
            this.Button_MF_About = new System.Windows.Forms.Button();
            this.GroupBox_MF_RunCountResults = new System.Windows.Forms.GroupBox();
            this.TextBox_MF_RR_CSVDir_RecordCount = new System.Windows.Forms.TextBox();
            this.Label_MF_RR_CSVDir_RecordCount = new System.Windows.Forms.Label();
            this.TextBox_MF_RR_CSVDir_FileCount = new System.Windows.Forms.TextBox();
            this.Button_MF_Run = new System.Windows.Forms.Button();
            this.Label_MF_RR_CSVDir_FileCount = new System.Windows.Forms.Label();
            this.TextBox_MF_RR_CSVSingle_Count = new System.Windows.Forms.TextBox();
            this.Label_MF_RR_CSVSingle_Count = new System.Windows.Forms.Label();
            this.Button_MF_Export = new System.Windows.Forms.Button();
            this.ListBox_MF_Status = new System.Windows.Forms.ListBox();
            this.groupBox_MF_PostProcessResults = new System.Windows.Forms.GroupBox();
            this.TextBox_MF_PPR_EndTime = new System.Windows.Forms.TextBox();
            this.Label_MF_PPR_EndTime = new System.Windows.Forms.Label();
            this.TextBox_MF_PPR_StartTime = new System.Windows.Forms.TextBox();
            this.Label_MF_PPR_StartTime = new System.Windows.Forms.Label();
            this.TextBox_MF_PPR_OwnersMuliple = new System.Windows.Forms.TextBox();
            this.Label_MF_PPR_OwnersMuliple = new System.Windows.Forms.Label();
            this.Button_MF_POST_PROCRESS = new System.Windows.Forms.Button();
            this.Button_MF_PPR_RestPerYear = new System.Windows.Forms.Button();
            this.Button_MF_PPR_InspPerYear = new System.Windows.Forms.Button();
            this.TextBox_MF_PPR_OwnersFound = new System.Windows.Forms.TextBox();
            this.Label_MF_PPR_OwnersFound = new System.Windows.Forms.Label();
            this.TextBox_MF_PPR_RestFound = new System.Windows.Forms.TextBox();
            this.TextBox_MF_PPR_UniqueInspections = new System.Windows.Forms.TextBox();
            this.Label_MF_PPR_RestFound = new System.Windows.Forms.Label();
            this.Label_MF_PPR_UniqueInspections = new System.Windows.Forms.Label();
            this.groupBox_MF_NMTC_Logo.SuspendLayout();
            this.GroupBox_MF_InputParameters.SuspendLayout();
            this.GroupBox_MF_RunCountResults.SuspendLayout();
            this.groupBox_MF_PostProcessResults.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_MF_NMTC_Logo
            // 
            this.groupBox_MF_NMTC_Logo.BackColor = System.Drawing.Color.IndianRed;
            this.groupBox_MF_NMTC_Logo.Controls.Add(this.Label_MF_NMTC_Title2);
            this.groupBox_MF_NMTC_Logo.Controls.Add(this.Label_MF_NMTC_Title1);
            this.groupBox_MF_NMTC_Logo.Location = new System.Drawing.Point(794, 2);
            this.groupBox_MF_NMTC_Logo.Name = "groupBox_MF_NMTC_Logo";
            this.groupBox_MF_NMTC_Logo.Size = new System.Drawing.Size(161, 186);
            this.groupBox_MF_NMTC_Logo.TabIndex = 0;
            this.groupBox_MF_NMTC_Logo.TabStop = false;
            // 
            // Label_MF_NMTC_Title2
            // 
            this.Label_MF_NMTC_Title2.AutoSize = true;
            this.Label_MF_NMTC_Title2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Label_MF_NMTC_Title2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_NMTC_Title2.ForeColor = System.Drawing.Color.White;
            this.Label_MF_NMTC_Title2.Location = new System.Drawing.Point(29, 83);
            this.Label_MF_NMTC_Title2.Name = "Label_MF_NMTC_Title2";
            this.Label_MF_NMTC_Title2.Size = new System.Drawing.Size(105, 40);
            this.Label_MF_NMTC_Title2.TabIndex = 2;
            this.Label_MF_NMTC_Title2.Text = "2021";
            // 
            // Label_MF_NMTC_Title1
            // 
            this.Label_MF_NMTC_Title1.AutoSize = true;
            this.Label_MF_NMTC_Title1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Label_MF_NMTC_Title1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_NMTC_Title1.ForeColor = System.Drawing.Color.White;
            this.Label_MF_NMTC_Title1.Location = new System.Drawing.Point(19, 43);
            this.Label_MF_NMTC_Title1.Name = "Label_MF_NMTC_Title1";
            this.Label_MF_NMTC_Title1.Size = new System.Drawing.Size(125, 40);
            this.Label_MF_NMTC_Title1.TabIndex = 1;
            this.Label_MF_NMTC_Title1.Text = "NMTC";
            // 
            // Label_MF_IP_InputCSV_File
            // 
            this.Label_MF_IP_InputCSV_File.AutoSize = true;
            this.Label_MF_IP_InputCSV_File.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_IP_InputCSV_File.Location = new System.Drawing.Point(9, 25);
            this.Label_MF_IP_InputCSV_File.Name = "Label_MF_IP_InputCSV_File";
            this.Label_MF_IP_InputCSV_File.Size = new System.Drawing.Size(186, 20);
            this.Label_MF_IP_InputCSV_File.TabIndex = 1;
            this.Label_MF_IP_InputCSV_File.Text = "Input CSV Single File:";
            // 
            // GroupBox_MF_InputParameters
            // 
            this.GroupBox_MF_InputParameters.BackColor = System.Drawing.Color.Tan;
            this.GroupBox_MF_InputParameters.Controls.Add(this.Button_MF_IP_CSVDir_Clear);
            this.GroupBox_MF_InputParameters.Controls.Add(this._MF_IP_CSVSingle_Clear);
            this.GroupBox_MF_InputParameters.Controls.Add(this.Button_MF_IP_OutputResultsDir_Browse);
            this.GroupBox_MF_InputParameters.Controls.Add(this.TextBox_MF_IP_OutputResultsDir);
            this.GroupBox_MF_InputParameters.Controls.Add(this.Label_MF_IP_OutputResultsDir);
            this.GroupBox_MF_InputParameters.Controls.Add(this.Button_MF_IP_CSVDir_Browse);
            this.GroupBox_MF_InputParameters.Controls.Add(this.TextBox_MF_IP_InputCSV_Dir);
            this.GroupBox_MF_InputParameters.Controls.Add(this.Label_MF_IP_InputCSV_Dir);
            this.GroupBox_MF_InputParameters.Controls.Add(this.Button_MF_IP_CSVSingle_Browse);
            this.GroupBox_MF_InputParameters.Controls.Add(this.TextBox_IP_MF_CSVSingle);
            this.GroupBox_MF_InputParameters.Controls.Add(this.Label_MF_IP_InputCSV_File);
            this.GroupBox_MF_InputParameters.Location = new System.Drawing.Point(3, 2);
            this.GroupBox_MF_InputParameters.Name = "GroupBox_MF_InputParameters";
            this.GroupBox_MF_InputParameters.Size = new System.Drawing.Size(785, 132);
            this.GroupBox_MF_InputParameters.TabIndex = 3;
            this.GroupBox_MF_InputParameters.TabStop = false;
            this.GroupBox_MF_InputParameters.Text = "Input Parameters";
            // 
            // Button_MF_IP_CSVDir_Clear
            // 
            this.Button_MF_IP_CSVDir_Clear.Location = new System.Drawing.Point(704, 56);
            this.Button_MF_IP_CSVDir_Clear.Name = "Button_MF_IP_CSVDir_Clear";
            this.Button_MF_IP_CSVDir_Clear.Size = new System.Drawing.Size(75, 24);
            this.Button_MF_IP_CSVDir_Clear.TabIndex = 15;
            this.Button_MF_IP_CSVDir_Clear.Text = "Clear";
            this.Button_MF_IP_CSVDir_Clear.UseVisualStyleBackColor = true;
            this.Button_MF_IP_CSVDir_Clear.Click += new System.EventHandler(this.Button_MF_IP_CSVDir_Clear_Click);
            // 
            // _MF_IP_CSVSingle_Clear
            // 
            this._MF_IP_CSVSingle_Clear.Location = new System.Drawing.Point(704, 27);
            this._MF_IP_CSVSingle_Clear.Name = "_MF_IP_CSVSingle_Clear";
            this._MF_IP_CSVSingle_Clear.Size = new System.Drawing.Size(75, 24);
            this._MF_IP_CSVSingle_Clear.TabIndex = 13;
            this._MF_IP_CSVSingle_Clear.Text = "Clear";
            this._MF_IP_CSVSingle_Clear.UseVisualStyleBackColor = true;
            this._MF_IP_CSVSingle_Clear.Click += new System.EventHandler(this._MF_IP_CSVSingle_Clear_Click);
            // 
            // Button_MF_IP_OutputResultsDir_Browse
            // 
            this.Button_MF_IP_OutputResultsDir_Browse.Location = new System.Drawing.Point(624, 97);
            this.Button_MF_IP_OutputResultsDir_Browse.Name = "Button_MF_IP_OutputResultsDir_Browse";
            this.Button_MF_IP_OutputResultsDir_Browse.Size = new System.Drawing.Size(75, 24);
            this.Button_MF_IP_OutputResultsDir_Browse.TabIndex = 12;
            this.Button_MF_IP_OutputResultsDir_Browse.Text = "Browse";
            this.Button_MF_IP_OutputResultsDir_Browse.UseVisualStyleBackColor = true;
            this.Button_MF_IP_OutputResultsDir_Browse.Click += new System.EventHandler(this.Button_MF_IP_OutDir_Browse_Click);
            // 
            // TextBox_MF_IP_OutputResultsDir
            // 
            this.TextBox_MF_IP_OutputResultsDir.Location = new System.Drawing.Point(248, 100);
            this.TextBox_MF_IP_OutputResultsDir.Name = "TextBox_MF_IP_OutputResultsDir";
            this.TextBox_MF_IP_OutputResultsDir.Size = new System.Drawing.Size(370, 20);
            this.TextBox_MF_IP_OutputResultsDir.TabIndex = 11;
            this.TextBox_MF_IP_OutputResultsDir.Tag = "";
            this.TextBox_MF_IP_OutputResultsDir.Text = "D:\\NMTC_BigData_Data";
            // 
            // Label_MF_IP_OutputResultsDir
            // 
            this.Label_MF_IP_OutputResultsDir.AutoSize = true;
            this.Label_MF_IP_OutputResultsDir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_IP_OutputResultsDir.Location = new System.Drawing.Point(9, 98);
            this.Label_MF_IP_OutputResultsDir.Name = "Label_MF_IP_OutputResultsDir";
            this.Label_MF_IP_OutputResultsDir.Size = new System.Drawing.Size(212, 20);
            this.Label_MF_IP_OutputResultsDir.TabIndex = 10;
            this.Label_MF_IP_OutputResultsDir.Text = "Output Results Directory:";
            // 
            // Button_MF_IP_CSVDir_Browse
            // 
            this.Button_MF_IP_CSVDir_Browse.Location = new System.Drawing.Point(624, 56);
            this.Button_MF_IP_CSVDir_Browse.Name = "Button_MF_IP_CSVDir_Browse";
            this.Button_MF_IP_CSVDir_Browse.Size = new System.Drawing.Size(75, 24);
            this.Button_MF_IP_CSVDir_Browse.TabIndex = 9;
            this.Button_MF_IP_CSVDir_Browse.Text = "Browse";
            this.Button_MF_IP_CSVDir_Browse.UseVisualStyleBackColor = true;
            this.Button_MF_IP_CSVDir_Browse.Click += new System.EventHandler(this.Button_MF_IP_CSVDir_Browse_Click);
            // 
            // TextBox_MF_IP_InputCSV_Dir
            // 
            this.TextBox_MF_IP_InputCSV_Dir.Location = new System.Drawing.Point(213, 60);
            this.TextBox_MF_IP_InputCSV_Dir.Name = "TextBox_MF_IP_InputCSV_Dir";
            this.TextBox_MF_IP_InputCSV_Dir.Size = new System.Drawing.Size(405, 20);
            this.TextBox_MF_IP_InputCSV_Dir.TabIndex = 8;
            this.TextBox_MF_IP_InputCSV_Dir.Text = "D:\\NMTC_BigData_Data\\CABQ-EXAMPLES\\OpenData_FoodInsceptions\\CSV\\Years";
            // 
            // Label_MF_IP_InputCSV_Dir
            // 
            this.Label_MF_IP_InputCSV_Dir.AutoSize = true;
            this.Label_MF_IP_InputCSV_Dir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_IP_InputCSV_Dir.Location = new System.Drawing.Point(6, 60);
            this.Label_MF_IP_InputCSV_Dir.Name = "Label_MF_IP_InputCSV_Dir";
            this.Label_MF_IP_InputCSV_Dir.Size = new System.Drawing.Size(174, 20);
            this.Label_MF_IP_InputCSV_Dir.TabIndex = 7;
            this.Label_MF_IP_InputCSV_Dir.Text = "Input CSV Directory:";
            // 
            // Button_MF_IP_CSVSingle_Browse
            // 
            this.Button_MF_IP_CSVSingle_Browse.Location = new System.Drawing.Point(624, 26);
            this.Button_MF_IP_CSVSingle_Browse.Name = "Button_MF_IP_CSVSingle_Browse";
            this.Button_MF_IP_CSVSingle_Browse.Size = new System.Drawing.Size(75, 24);
            this.Button_MF_IP_CSVSingle_Browse.TabIndex = 3;
            this.Button_MF_IP_CSVSingle_Browse.Text = "Browse";
            this.Button_MF_IP_CSVSingle_Browse.UseVisualStyleBackColor = true;
            this.Button_MF_IP_CSVSingle_Browse.Click += new System.EventHandler(this.Button_MF_IP_CSVSingle_Browse_Click);
            // 
            // TextBox_IP_MF_CSVSingle
            // 
            this.TextBox_IP_MF_CSVSingle.Location = new System.Drawing.Point(213, 27);
            this.TextBox_IP_MF_CSVSingle.Name = "TextBox_IP_MF_CSVSingle";
            this.TextBox_IP_MF_CSVSingle.Size = new System.Drawing.Size(405, 20);
            this.TextBox_IP_MF_CSVSingle.TabIndex = 2;
            this.TextBox_IP_MF_CSVSingle.Text = "D:\\NMTC_BigData_Data\\CABQ-EXAMPLES\\OpenData_FoodInsceptions\\CSV\\FoodInspectionsCA" +
    "BQ-en-us.csv";
            // 
            // Button_MF_Exit
            // 
            this.Button_MF_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_MF_Exit.Location = new System.Drawing.Point(875, 368);
            this.Button_MF_Exit.Name = "Button_MF_Exit";
            this.Button_MF_Exit.Size = new System.Drawing.Size(75, 24);
            this.Button_MF_Exit.TabIndex = 7;
            this.Button_MF_Exit.Text = "Exit";
            this.Button_MF_Exit.UseVisualStyleBackColor = true;
            this.Button_MF_Exit.Click += new System.EventHandler(this.Button_MF_Exit_Click);
            // 
            // Button_MF_Help
            // 
            this.Button_MF_Help.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_MF_Help.Location = new System.Drawing.Point(794, 367);
            this.Button_MF_Help.Name = "Button_MF_Help";
            this.Button_MF_Help.Size = new System.Drawing.Size(75, 24);
            this.Button_MF_Help.TabIndex = 8;
            this.Button_MF_Help.Text = "Help";
            this.Button_MF_Help.UseVisualStyleBackColor = true;
            this.Button_MF_Help.Click += new System.EventHandler(this.Button_MF_Help_Click);
            // 
            // Button_MF_About
            // 
            this.Button_MF_About.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_MF_About.Location = new System.Drawing.Point(701, 367);
            this.Button_MF_About.Name = "Button_MF_About";
            this.Button_MF_About.Size = new System.Drawing.Size(75, 24);
            this.Button_MF_About.TabIndex = 9;
            this.Button_MF_About.Text = "About";
            this.Button_MF_About.UseVisualStyleBackColor = true;
            this.Button_MF_About.Click += new System.EventHandler(this.Button_MF_About_Click);
            // 
            // GroupBox_MF_RunCountResults
            // 
            this.GroupBox_MF_RunCountResults.BackColor = System.Drawing.Color.Tan;
            this.GroupBox_MF_RunCountResults.Controls.Add(this.TextBox_MF_RR_CSVDir_RecordCount);
            this.GroupBox_MF_RunCountResults.Controls.Add(this.Label_MF_RR_CSVDir_RecordCount);
            this.GroupBox_MF_RunCountResults.Controls.Add(this.TextBox_MF_RR_CSVDir_FileCount);
            this.GroupBox_MF_RunCountResults.Controls.Add(this.Button_MF_Run);
            this.GroupBox_MF_RunCountResults.Controls.Add(this.Label_MF_RR_CSVDir_FileCount);
            this.GroupBox_MF_RunCountResults.Controls.Add(this.TextBox_MF_RR_CSVSingle_Count);
            this.GroupBox_MF_RunCountResults.Controls.Add(this.Label_MF_RR_CSVSingle_Count);
            this.GroupBox_MF_RunCountResults.Location = new System.Drawing.Point(3, 140);
            this.GroupBox_MF_RunCountResults.Name = "GroupBox_MF_RunCountResults";
            this.GroupBox_MF_RunCountResults.Size = new System.Drawing.Size(681, 111);
            this.GroupBox_MF_RunCountResults.TabIndex = 13;
            this.GroupBox_MF_RunCountResults.TabStop = false;
            this.GroupBox_MF_RunCountResults.Text = "Run Count Results";
            // 
            // TextBox_MF_RR_CSVDir_RecordCount
            // 
            this.TextBox_MF_RR_CSVDir_RecordCount.Location = new System.Drawing.Point(570, 54);
            this.TextBox_MF_RR_CSVDir_RecordCount.Name = "TextBox_MF_RR_CSVDir_RecordCount";
            this.TextBox_MF_RR_CSVDir_RecordCount.Size = new System.Drawing.Size(99, 20);
            this.TextBox_MF_RR_CSVDir_RecordCount.TabIndex = 24;
            // 
            // Label_MF_RR_CSVDir_RecordCount
            // 
            this.Label_MF_RR_CSVDir_RecordCount.AutoSize = true;
            this.Label_MF_RR_CSVDir_RecordCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_RR_CSVDir_RecordCount.Location = new System.Drawing.Point(393, 54);
            this.Label_MF_RR_CSVDir_RecordCount.Name = "Label_MF_RR_CSVDir_RecordCount";
            this.Label_MF_RR_CSVDir_RecordCount.Size = new System.Drawing.Size(171, 20);
            this.Label_MF_RR_CSVDir_RecordCount.TabIndex = 23;
            this.Label_MF_RR_CSVDir_RecordCount.Text = "CSV Record  Count:";
            // 
            // TextBox_MF_RR_CSVDir_FileCount
            // 
            this.TextBox_MF_RR_CSVDir_FileCount.Location = new System.Drawing.Point(570, 26);
            this.TextBox_MF_RR_CSVDir_FileCount.Name = "TextBox_MF_RR_CSVDir_FileCount";
            this.TextBox_MF_RR_CSVDir_FileCount.Size = new System.Drawing.Size(99, 20);
            this.TextBox_MF_RR_CSVDir_FileCount.TabIndex = 20;
            // 
            // Button_MF_Run
            // 
            this.Button_MF_Run.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Button_MF_Run.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_MF_Run.Location = new System.Drawing.Point(45, 66);
            this.Button_MF_Run.Name = "Button_MF_Run";
            this.Button_MF_Run.Size = new System.Drawing.Size(75, 25);
            this.Button_MF_Run.TabIndex = 14;
            this.Button_MF_Run.Text = "RUN";
            this.Button_MF_Run.UseVisualStyleBackColor = false;
            this.Button_MF_Run.Click += new System.EventHandler(this.Button_MF_Run_Click);
            // 
            // Label_MF_RR_CSVDir_FileCount
            // 
            this.Label_MF_RR_CSVDir_FileCount.AutoSize = true;
            this.Label_MF_RR_CSVDir_FileCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_RR_CSVDir_FileCount.Location = new System.Drawing.Point(341, 26);
            this.Label_MF_RR_CSVDir_FileCount.Name = "Label_MF_RR_CSVDir_FileCount";
            this.Label_MF_RR_CSVDir_FileCount.Size = new System.Drawing.Size(223, 20);
            this.Label_MF_RR_CSVDir_FileCount.TabIndex = 19;
            this.Label_MF_RR_CSVDir_FileCount.Text = "CSV Directory Files Count:";
            // 
            // TextBox_MF_RR_CSVSingle_Count
            // 
            this.TextBox_MF_RR_CSVSingle_Count.Location = new System.Drawing.Point(236, 28);
            this.TextBox_MF_RR_CSVSingle_Count.Name = "TextBox_MF_RR_CSVSingle_Count";
            this.TextBox_MF_RR_CSVSingle_Count.Size = new System.Drawing.Size(99, 20);
            this.TextBox_MF_RR_CSVSingle_Count.TabIndex = 17;
            // 
            // Label_MF_RR_CSVSingle_Count
            // 
            this.Label_MF_RR_CSVSingle_Count.AutoSize = true;
            this.Label_MF_RR_CSVSingle_Count.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_RR_CSVSingle_Count.Location = new System.Drawing.Point(9, 28);
            this.Label_MF_RR_CSVSingle_Count.Name = "Label_MF_RR_CSVSingle_Count";
            this.Label_MF_RR_CSVSingle_Count.Size = new System.Drawing.Size(221, 20);
            this.Label_MF_RR_CSVSingle_Count.TabIndex = 13;
            this.Label_MF_RR_CSVSingle_Count.Text = "CSV Single Record Count:";
            // 
            // Button_MF_Export
            // 
            this.Button_MF_Export.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_MF_Export.Location = new System.Drawing.Point(701, 140);
            this.Button_MF_Export.Name = "Button_MF_Export";
            this.Button_MF_Export.Size = new System.Drawing.Size(75, 48);
            this.Button_MF_Export.TabIndex = 15;
            this.Button_MF_Export.Text = "Export Results";
            this.Button_MF_Export.UseVisualStyleBackColor = true;
            this.Button_MF_Export.Click += new System.EventHandler(this.Button_MF_Export_Click);
            // 
            // ListBox_MF_Status
            // 
            this.ListBox_MF_Status.FormattingEnabled = true;
            this.ListBox_MF_Status.Location = new System.Drawing.Point(690, 194);
            this.ListBox_MF_Status.Name = "ListBox_MF_Status";
            this.ListBox_MF_Status.Size = new System.Drawing.Size(265, 160);
            this.ListBox_MF_Status.TabIndex = 16;
            // 
            // groupBox_MF_PostProcessResults
            // 
            this.groupBox_MF_PostProcessResults.BackColor = System.Drawing.Color.Tan;
            this.groupBox_MF_PostProcessResults.Controls.Add(this.TextBox_MF_PPR_EndTime);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.Label_MF_PPR_EndTime);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.TextBox_MF_PPR_StartTime);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.Label_MF_PPR_StartTime);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.TextBox_MF_PPR_OwnersMuliple);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.Label_MF_PPR_OwnersMuliple);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.Button_MF_POST_PROCRESS);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.Button_MF_PPR_RestPerYear);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.Button_MF_PPR_InspPerYear);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.TextBox_MF_PPR_OwnersFound);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.Label_MF_PPR_OwnersFound);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.TextBox_MF_PPR_RestFound);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.TextBox_MF_PPR_UniqueInspections);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.Label_MF_PPR_RestFound);
            this.groupBox_MF_PostProcessResults.Controls.Add(this.Label_MF_PPR_UniqueInspections);
            this.groupBox_MF_PostProcessResults.Location = new System.Drawing.Point(3, 257);
            this.groupBox_MF_PostProcessResults.Name = "groupBox_MF_PostProcessResults";
            this.groupBox_MF_PostProcessResults.Size = new System.Drawing.Size(681, 141);
            this.groupBox_MF_PostProcessResults.TabIndex = 27;
            this.groupBox_MF_PostProcessResults.TabStop = false;
            this.groupBox_MF_PostProcessResults.Text = "Post Process Results";
            // 
            // TextBox_MF_PPR_EndTime
            // 
            this.TextBox_MF_PPR_EndTime.Location = new System.Drawing.Point(467, 108);
            this.TextBox_MF_PPR_EndTime.Name = "TextBox_MF_PPR_EndTime";
            this.TextBox_MF_PPR_EndTime.Size = new System.Drawing.Size(75, 20);
            this.TextBox_MF_PPR_EndTime.TabIndex = 36;
            // 
            // Label_MF_PPR_EndTime
            // 
            this.Label_MF_PPR_EndTime.AutoSize = true;
            this.Label_MF_PPR_EndTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_PPR_EndTime.Location = new System.Drawing.Point(367, 108);
            this.Label_MF_PPR_EndTime.Name = "Label_MF_PPR_EndTime";
            this.Label_MF_PPR_EndTime.Size = new System.Drawing.Size(94, 20);
            this.Label_MF_PPR_EndTime.TabIndex = 35;
            this.Label_MF_PPR_EndTime.Text = "End Time::";
            // 
            // TextBox_MF_PPR_StartTime
            // 
            this.TextBox_MF_PPR_StartTime.Location = new System.Drawing.Point(276, 110);
            this.TextBox_MF_PPR_StartTime.Name = "TextBox_MF_PPR_StartTime";
            this.TextBox_MF_PPR_StartTime.Size = new System.Drawing.Size(75, 20);
            this.TextBox_MF_PPR_StartTime.TabIndex = 34;
            // 
            // Label_MF_PPR_StartTime
            // 
            this.Label_MF_PPR_StartTime.AutoSize = true;
            this.Label_MF_PPR_StartTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_PPR_StartTime.Location = new System.Drawing.Point(180, 110);
            this.Label_MF_PPR_StartTime.Name = "Label_MF_PPR_StartTime";
            this.Label_MF_PPR_StartTime.Size = new System.Drawing.Size(102, 20);
            this.Label_MF_PPR_StartTime.TabIndex = 33;
            this.Label_MF_PPR_StartTime.Text = "Start Time::";
            // 
            // TextBox_MF_PPR_OwnersMuliple
            // 
            this.TextBox_MF_PPR_OwnersMuliple.Location = new System.Drawing.Point(495, 73);
            this.TextBox_MF_PPR_OwnersMuliple.Name = "TextBox_MF_PPR_OwnersMuliple";
            this.TextBox_MF_PPR_OwnersMuliple.Size = new System.Drawing.Size(75, 20);
            this.TextBox_MF_PPR_OwnersMuliple.TabIndex = 32;
            // 
            // Label_MF_PPR_OwnersMuliple
            // 
            this.Label_MF_PPR_OwnersMuliple.AutoSize = true;
            this.Label_MF_PPR_OwnersMuliple.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_PPR_OwnersMuliple.Location = new System.Drawing.Point(303, 73);
            this.Label_MF_PPR_OwnersMuliple.Name = "Label_MF_PPR_OwnersMuliple";
            this.Label_MF_PPR_OwnersMuliple.Size = new System.Drawing.Size(186, 20);
            this.Label_MF_PPR_OwnersMuliple.TabIndex = 31;
            this.Label_MF_PPR_OwnersMuliple.Text = "Owns More Than One:";
            // 
            // Button_MF_POST_PROCRESS
            // 
            this.Button_MF_POST_PROCRESS.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Button_MF_POST_PROCRESS.Location = new System.Drawing.Point(45, 110);
            this.Button_MF_POST_PROCRESS.Name = "Button_MF_POST_PROCRESS";
            this.Button_MF_POST_PROCRESS.Size = new System.Drawing.Size(75, 25);
            this.Button_MF_POST_PROCRESS.TabIndex = 28;
            this.Button_MF_POST_PROCRESS.Text = "Process";
            this.Button_MF_POST_PROCRESS.UseVisualStyleBackColor = false;
            this.Button_MF_POST_PROCRESS.Click += new System.EventHandler(this.Button_MF_POST_PROCRESS_Click);
            // 
            // Button_MF_PPR_RestPerYear
            // 
            this.Button_MF_PPR_RestPerYear.Location = new System.Drawing.Point(584, 63);
            this.Button_MF_PPR_RestPerYear.Name = "Button_MF_PPR_RestPerYear";
            this.Button_MF_PPR_RestPerYear.Size = new System.Drawing.Size(75, 42);
            this.Button_MF_PPR_RestPerYear.TabIndex = 30;
            this.Button_MF_PPR_RestPerYear.Text = "Restaurants per year";
            this.Button_MF_PPR_RestPerYear.UseVisualStyleBackColor = true;
            this.Button_MF_PPR_RestPerYear.Click += new System.EventHandler(this.Button_MF_PPR_RestPerYear_Click);
            // 
            // Button_MF_PPR_InspPerYear
            // 
            this.Button_MF_PPR_InspPerYear.Location = new System.Drawing.Point(584, 15);
            this.Button_MF_PPR_InspPerYear.Name = "Button_MF_PPR_InspPerYear";
            this.Button_MF_PPR_InspPerYear.Size = new System.Drawing.Size(75, 42);
            this.Button_MF_PPR_InspPerYear.TabIndex = 29;
            this.Button_MF_PPR_InspPerYear.Text = "Inspections Per Year";
            this.Button_MF_PPR_InspPerYear.UseVisualStyleBackColor = true;
            this.Button_MF_PPR_InspPerYear.Click += new System.EventHandler(this.Button_MF_PPR_InspPerYear_Click);
            // 
            // TextBox_MF_PPR_OwnersFound
            // 
            this.TextBox_MF_PPR_OwnersFound.Location = new System.Drawing.Point(439, 37);
            this.TextBox_MF_PPR_OwnersFound.Name = "TextBox_MF_PPR_OwnersFound";
            this.TextBox_MF_PPR_OwnersFound.Size = new System.Drawing.Size(75, 20);
            this.TextBox_MF_PPR_OwnersFound.TabIndex = 28;
            // 
            // Label_MF_PPR_OwnersFound
            // 
            this.Label_MF_PPR_OwnersFound.AutoSize = true;
            this.Label_MF_PPR_OwnersFound.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_PPR_OwnersFound.Location = new System.Drawing.Point(303, 35);
            this.Label_MF_PPR_OwnersFound.Name = "Label_MF_PPR_OwnersFound";
            this.Label_MF_PPR_OwnersFound.Size = new System.Drawing.Size(130, 20);
            this.Label_MF_PPR_OwnersFound.TabIndex = 27;
            this.Label_MF_PPR_OwnersFound.Text = "Owners Found:";
            // 
            // TextBox_MF_PPR_RestFound
            // 
            this.TextBox_MF_PPR_RestFound.Location = new System.Drawing.Point(184, 69);
            this.TextBox_MF_PPR_RestFound.Name = "TextBox_MF_PPR_RestFound";
            this.TextBox_MF_PPR_RestFound.Size = new System.Drawing.Size(75, 20);
            this.TextBox_MF_PPR_RestFound.TabIndex = 18;
            // 
            // TextBox_MF_PPR_UniqueInspections
            // 
            this.TextBox_MF_PPR_UniqueInspections.Location = new System.Drawing.Point(182, 35);
            this.TextBox_MF_PPR_UniqueInspections.Name = "TextBox_MF_PPR_UniqueInspections";
            this.TextBox_MF_PPR_UniqueInspections.Size = new System.Drawing.Size(77, 20);
            this.TextBox_MF_PPR_UniqueInspections.TabIndex = 17;
            // 
            // Label_MF_PPR_RestFound
            // 
            this.Label_MF_PPR_RestFound.AutoSize = true;
            this.Label_MF_PPR_RestFound.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_PPR_RestFound.Location = new System.Drawing.Point(6, 69);
            this.Label_MF_PPR_RestFound.Name = "Label_MF_PPR_RestFound";
            this.Label_MF_PPR_RestFound.Size = new System.Drawing.Size(169, 20);
            this.Label_MF_PPR_RestFound.TabIndex = 14;
            this.Label_MF_PPR_RestFound.Text = "Restaurants Found:";
            // 
            // Label_MF_PPR_UniqueInspections
            // 
            this.Label_MF_PPR_UniqueInspections.AutoSize = true;
            this.Label_MF_PPR_UniqueInspections.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MF_PPR_UniqueInspections.Location = new System.Drawing.Point(7, 33);
            this.Label_MF_PPR_UniqueInspections.Name = "Label_MF_PPR_UniqueInspections";
            this.Label_MF_PPR_UniqueInspections.Size = new System.Drawing.Size(169, 20);
            this.Label_MF_PPR_UniqueInspections.TabIndex = 13;
            this.Label_MF_PPR_UniqueInspections.Text = "Unique Inspections:";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(960, 409);
            this.Controls.Add(this.groupBox_MF_PostProcessResults);
            this.Controls.Add(this.ListBox_MF_Status);
            this.Controls.Add(this.Button_MF_Export);
            this.Controls.Add(this.GroupBox_MF_RunCountResults);
            this.Controls.Add(this.Button_MF_About);
            this.Controls.Add(this.Button_MF_Help);
            this.Controls.Add(this.Button_MF_Exit);
            this.Controls.Add(this.GroupBox_MF_InputParameters);
            this.Controls.Add(this.groupBox_MF_NMTC_Logo);
            this.Name = "MainForm";
            this.Text = "NMTC Big Data Presentation - Record Counter/Record Processor";
            this.groupBox_MF_NMTC_Logo.ResumeLayout(false);
            this.groupBox_MF_NMTC_Logo.PerformLayout();
            this.GroupBox_MF_InputParameters.ResumeLayout(false);
            this.GroupBox_MF_InputParameters.PerformLayout();
            this.GroupBox_MF_RunCountResults.ResumeLayout(false);
            this.GroupBox_MF_RunCountResults.PerformLayout();
            this.groupBox_MF_PostProcessResults.ResumeLayout(false);
            this.groupBox_MF_PostProcessResults.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_MF_NMTC_Logo;
        private System.Windows.Forms.Label Label_MF_NMTC_Title1;
        private System.Windows.Forms.Label Label_MF_NMTC_Title2;
        private System.Windows.Forms.Label Label_MF_IP_InputCSV_File;
        private System.Windows.Forms.GroupBox GroupBox_MF_InputParameters;
        private System.Windows.Forms.Button Button_MF_IP_CSVSingle_Browse;
        private System.Windows.Forms.TextBox TextBox_IP_MF_CSVSingle;
        private System.Windows.Forms.Button Button_MF_IP_CSVDir_Clear;
        private System.Windows.Forms.Button _MF_IP_CSVSingle_Clear;
        private System.Windows.Forms.Button Button_MF_IP_OutputResultsDir_Browse;
        private System.Windows.Forms.TextBox TextBox_MF_IP_OutputResultsDir;
        private System.Windows.Forms.Label Label_MF_IP_OutputResultsDir;
        private System.Windows.Forms.Button Button_MF_IP_CSVDir_Browse;
        private System.Windows.Forms.TextBox TextBox_MF_IP_InputCSV_Dir;
        private System.Windows.Forms.Label Label_MF_IP_InputCSV_Dir;
        private System.Windows.Forms.Button Button_MF_Exit;
        private System.Windows.Forms.Button Button_MF_Help;
        private System.Windows.Forms.Button Button_MF_About;
        private System.Windows.Forms.GroupBox GroupBox_MF_RunCountResults;
        private System.Windows.Forms.TextBox TextBox_MF_RR_CSVDir_RecordCount;
        private System.Windows.Forms.Label Label_MF_RR_CSVDir_RecordCount;
        private System.Windows.Forms.TextBox TextBox_MF_RR_CSVDir_FileCount;
        private System.Windows.Forms.Label Label_MF_RR_CSVDir_FileCount;
        private System.Windows.Forms.TextBox TextBox_MF_RR_CSVSingle_Count;
        private System.Windows.Forms.Label Label_MF_RR_CSVSingle_Count;
        private System.Windows.Forms.Button Button_MF_Run;
        private System.Windows.Forms.Button Button_MF_Export;
        private System.Windows.Forms.ListBox ListBox_MF_Status;
        private System.Windows.Forms.GroupBox groupBox_MF_PostProcessResults;
        private System.Windows.Forms.TextBox TextBox_MF_PPR_RestFound;
        private System.Windows.Forms.TextBox TextBox_MF_PPR_UniqueInspections;
        private System.Windows.Forms.Label Label_MF_PPR_RestFound;
        private System.Windows.Forms.Label Label_MF_PPR_UniqueInspections;
        private System.Windows.Forms.Button Button_MF_POST_PROCRESS;
        private System.Windows.Forms.Button Button_MF_PPR_RestPerYear;
        private System.Windows.Forms.Button Button_MF_PPR_InspPerYear;
        private System.Windows.Forms.TextBox TextBox_MF_PPR_OwnersFound;
        private System.Windows.Forms.Label Label_MF_PPR_OwnersFound;
        private System.Windows.Forms.TextBox TextBox_MF_PPR_OwnersMuliple;
        private System.Windows.Forms.Label Label_MF_PPR_OwnersMuliple;
        private System.Windows.Forms.TextBox TextBox_MF_PPR_EndTime;
        private System.Windows.Forms.Label Label_MF_PPR_EndTime;
        private System.Windows.Forms.TextBox TextBox_MF_PPR_StartTime;
        private System.Windows.Forms.Label Label_MF_PPR_StartTime;
    }
}

